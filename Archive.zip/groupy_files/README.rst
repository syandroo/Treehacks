======
Groupy
======

.. image:: https://img.shields.io/pypi/v/GroupyAPI.svg
	:target: https://pypi.python.org/pypi/GroupyAPI

.. image:: https://travis-ci.org/rhgrant10/Groupy.svg?branch=dev
	:target: https://travis-ci.org/rhgrant10/Groupy

.. image:: https://readthedocs.org/projects/groupy/badge/?version=latest
	:target: https://groupy.readthedocs.org/en/latest

The simple yet powerful GroupMe API wrapper for Python.

 - `Full Documentation`_
     - `Installation`_
     - `Basic Usage`_
     - `Contributing`_

.. _Full Documentation: http://groupy.readthedocs.org/en/latest/
.. _Installation: http://groupy.readthedocs.org/en/latest/pages/installation.html
.. _Basic Usage: http://http://groupy.readthedocs.org/en/latest/pages/quickstart.html
.. _Contributing: http://groupy.readthedocs.org/en/latest/pages/contributing.html
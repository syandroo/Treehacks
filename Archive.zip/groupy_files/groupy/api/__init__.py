"""This module is a direct wrapper around GroupMe API calls.

.. module:: api
   :platform: Unix, Windows
   :synopsis: A wrapper for the GroupMe API

.. moduleauthor:: Robert Grant <rhgrant10@gmail.com>

"""
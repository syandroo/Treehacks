"""
This module previously provided an interface to Babelfish online
translation service; this service is no longer available; this
module is kept in NLTK source code in order to provide better error
messages for people following the NLTK Book 2.0.
"""
from __future__ import print_function

def babelize_shell():
    print("Babelfish online translation service is no longer available.")
